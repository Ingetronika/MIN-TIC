package com.example.myAppg4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyAppG4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
